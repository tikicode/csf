Contributions
--------------
MS1
Arijit worked on the main.cpp command line input logic. Arijit and Taran
worked on the cache initial implementation together.
 MS2
 Taran and Arijit worked together predomintantly and both commented and tested extensively