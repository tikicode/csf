Contributions
-------------
Arijit
- get_bits
- create_from_hex
- format_as_hex
- rotate_left
- rotate_right

Taran
- create_from_u32
- create
- add
- sub
- negate
